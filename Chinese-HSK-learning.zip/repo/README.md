# Chinese HSK Learning – Mỗi ngày một chút

Web học tiếng Trung từ con số 0 tới HSK 3, dành cho người Việt. Toàn bộ app nằm trong một file `index.html`, không cần cài đặt hay server.

## Tính năng

- **Lộ trình mỗi ngày 2 bước:** ôn tập (từ đến hạn, từ hay sai, ngữ pháp, viết lại chữ; Chủ nhật có ôn tuần) rồi học từ mới.
- **604 từ HSK 1–3** kèm pinyin, nghĩa tiếng Việt, âm Hán Việt, phát âm mẫu.
- **Lặp lại ngắt quãng (SRS)** tự xếp lịch ôn, tự chia số từ mới/ngày theo ngày thi mục tiêu.
- **Tập viết** bằng ngón tay theo thứ tự nét (Hanzi Writer), 3 chế độ: xem nét, viết theo, tự viết.
- **34 điểm ngữ pháp HSK 1–3** với câu mẫu, bài điền từ và xếp câu.
- **Tranh chữ:** 25 chữ tượng hình có hình vẽ, 29 chữ ghép kèm câu chuyện, 25 bộ thủ.
- **Phần thưởng:** XP, cấp độ, chuỗi ngày, con dấu 印 theo ngày, xu, cửa hàng, 18 huy hiệu.
- Bài 0 về thanh điệu và mẹo phát âm cho người Việt.

## Chạy app

Mở `index.html` bằng trình duyệt là dùng được. Để dùng trên điện thoại, bật GitHub Pages:
Settings → Pages → Source: *Deploy from a branch* → Branch: `main`, thư mục `/ (root)` → Save.
Sau ~1 phút app có ở `https://linhtran5399.github.io/Chinese-HSK-learning/`.

## Ghi chú

- Ngoài Claude, tiến độ được lưu trong trình duyệt (localStorage) trên từng máy.
- Phát âm dùng giọng đọc tiếng Trung có sẵn của thiết bị (Web Speech API).
- Dữ liệu nét chữ: [hanzi-writer-data](https://github.com/chanind/hanzi-writer-data) (Arphic Public License); thư viện vẽ nét: [Hanzi Writer](https://github.com/chanind/hanzi-writer) (MIT).
- Bộ từ là lõi HSK 1–3 bản 2.0. HSK 3 theo chuẩn mới (HSK 3.0) cần khoảng 1.000 từ; có thể thêm từ trong mục *Từ & chữ → Danh sách từ*.
